package assignment2;

import java.util.*;

public class Student {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter number of student");
        int noOfStudent = sc.nextInt();

        Map<Integer, List<String>> myMaps = new HashMap<Integer, List<String>>();

        for (int i = 1 ; i <= noOfStudent; i++){
            List<String> list = new ArrayList<>();
            System.out.println("Please enter number of studentname");
            String  student_name = sc.next();
            list.add(student_name);
            myMaps.put(i,list);

            System.out.println("Please enter number of studentemail");
            String student_email = sc.next();
            list.add(student_email);
            myMaps.put(i,list);

            System.out.println("Please enter number of studentphone");
            String Student_phone = sc.next();
            list.add(Student_phone);
            myMaps.put(i,list);

            System.out.println("Please enter number of studentaddress");
            String Student_address = sc.next();
            list.add(Student_address);
            myMaps.put(i,list);

            System.out.println("Please enter number of studentstatus");
            String Student_status = sc.next();
            list.add(Student_status);
            myMaps.put(i,list);
        }

        System.out.println("Please enter the student details you are looking for");
        int id = sc.nextInt();
                for (Map.Entry<Integer, List<String>> it: myMaps.entrySet()) {
                    if (it.getKey().equals(id)){
                        System.out.print(it.getValue()+" ");
                    }
        }



    }
}
