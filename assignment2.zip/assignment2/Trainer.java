package assignment2;

public class Trainer {

    String name;
    String department;
    String email;
    int id;

    public Trainer(String tname, String tdept, String temail, int tid){
         name =  tname;
         department = tdept;
         email = temail;
         id = tid;
    }

    public static void main(String[] args) {
        String trainer_selenium [] = {"Mukesh","Selenium","mukesh@gmail.com","1"};
        String trainer_webdev [] = {"Hitesh","Web Development","hitesh@gmail.com","2"};
        String trainer_devops [] = {"Naveen","DevOps","naveen@gmail.com","3"};

        Trainer t1 = new Trainer("Mukesh","Selenium","mukesh@gmail.com,",1);
        Trainer t2 = new Trainer("Hitesh","Web Development","hitesh@gmail.com,",2);
        Trainer t3 = new Trainer("Naveen","DevOps","naveen@gmail.com,",3);
        System.out.println(t1.name);


    }
}
