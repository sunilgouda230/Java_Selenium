package Assignment9;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.AbstractCollection;
import java.util.List;

public class Task1 {
    private static final String name = "name";
    private static final String email = "email";
    private static final String password = "password";


    public static String signup(WebDriver driver, String username, String emailId, String pass, String Interests
            , String gender, String state) throws InterruptedException {
        boolean singup_header = driver.findElements(By.xpath("//h2[text()='Sign Up']")).size() > 0;

        while (!singup_header) {
            driver.navigate().refresh();
        }


        WebElement enable = driver.findElement(By.xpath("//button[contains(text(),'Sign up')]"));

        if (!enable.isEnabled()) {
            driver.findElement(By.id(name)).sendKeys(username);
            driver.findElement(By.id(email)).sendKeys(emailId);
            driver.findElement(By.id(password)).sendKeys(pass);

            driver.findElement(By.xpath("//label[contains(text(),'" + Interests + "')]//parent::div/input")).click();

            driver.findElement(By.xpath("//label[contains(text(),'" + gender + "')]//parent::div/input")).click();

            List<WebElement> list = driver.findElements(By.xpath("//select[@id='state']/option"));

            for (WebElement val : list) {
                if (val.getText().equals(state)) {
                    val.click();
                }
            }

            WebElement element = driver.findElement(By.xpath("//button[text()='Sign up']"));

            JavascriptExecutor executor = (JavascriptExecutor) driver;
            if (enable.isEnabled()) {
                executor.executeScript("arguments[0].click();", element);
            } else {
                return "You need sign up first!!";
            }

            Thread.sleep(5000);

            if (driver.getCurrentUrl().contains("login")) {
                WebElement sign_in = driver.findElement(By.xpath("//button[text()='Sign in']"));
                driver.findElement(By.xpath("//input[contains(@id,'email')]")).sendKeys(emailId);
                driver.findElement(By.xpath("//input[contains(@id,'pass')]")).sendKeys(pass);
                executor.executeScript("arguments[0].click();", sign_in);

                String welcome_msg = driver.findElement(By.xpath("//h4[@class='welcomeMessage']")).getText();

                String user_name[] = welcome_msg.split(" ");
                String cur_user[] = username.split(" ");
                String cur = "";
                int k = 0;
                for (int i = 0; i < user_name.length; i++) {
                    try {
                        if (user_name[i].equals(cur_user[k])) {
                            cur += cur_user[k] + " ";
                            k++;
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("User logged in !!");
                    }
                    break;
                }
            }
        } else {
            return "You need sign up first!!";
        }


        return "signup success!!!";
    }


    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://ineuron-courses.vercel.app/signup");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        String user_signup = signup(driver, "puja mishra", "sunilgouda024@gmail.com", "123@sunil", "Testing",
                "Male", "Odisha");

        System.out.println(user_signup);
    }
}
