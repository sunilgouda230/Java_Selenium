package assignment1;

public class Task4 {
    public static void main(String[] args) {
        //Write a program to print all odd numbers from 1-50
        for (int i =1; i <= 50; i++){
            if (i % 2 != 0){
                System.out.print(i+" ");
            }
        }
    }
}
