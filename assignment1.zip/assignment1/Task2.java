package assignment1;

public class Task2 {
    //Task 2-  Write a program to print the sum of below 5 numbers.
    //	10,90.78,111,8989,7876
    public static void main(String[] args) {
        int a = 10;
        double b = 90.78;
        int c = 111;
        int d = 8989;
        int e = 7876;

        System.out.println(a+b+c+d+e);
    }

}
