package assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        //Write a program which can store List of Integer values and print all the values using for loop.
        Scanner sc = new Scanner(System.in);
        List<Integer> list = new ArrayList<>();
        System.out.println("Enter no of  value integer");
        int val = sc.nextInt();
        System.out.println("enter values now!!!");
        for (int i = 0; i < val; i++){
            int values = sc.nextInt();
            list.add(values);
        }

        for ( Integer li: list) {
            System.out.print(li+" ");
        }

    }
}
