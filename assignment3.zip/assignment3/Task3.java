package assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task3 {

    public static void main(String[] args) {
        //Write a program which will print sum of all numbers which is stored in list.
        Scanner sc = new Scanner(System.in);
        List<Integer> list = new ArrayList<>();
        System.out.println("Enter no of  value integer");
        int val = sc.nextInt();
        int sum = 0;
        System.out.println("enter values now!!!");
        for (int i = 0; i < val; i++){
            int values = sc.nextInt();
            list.add(values);
        }

        for (int i = 0; i < list.size(); i++){
            sum = sum + list.get(i);
        }
        System.out.println("Total Sum"+sum);
    }
}
