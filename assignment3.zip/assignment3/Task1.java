package assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        //Write a program which can store List of Integer values and print all the values using for loop.
        Scanner sc = new Scanner(System.in);
        List<Integer> list = new ArrayList<>();
        System.out.println("Enter 5 value integer");
        int val = 5;
        for (int i = 0; i < val; i++){
            int values = sc.nextInt();
            list.add(values);
        }

        for (int i = 0; i < list.size(); i++){
            System.out.print(list.get(i)+" ");
        }

        }
}
