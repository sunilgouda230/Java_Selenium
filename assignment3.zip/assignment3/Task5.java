package assignment3;

import java.util.ArrayList;
import java.util.List;

public class Task5 {

    public static void main(String[] args) {
        //33,44,55,66,77,88
        List<Integer> list = new ArrayList<>();
        list.add(33);
        list.add(44);
        list.add(55);
        list.add(66);
        list.add(77);
        list.add(88);








        list.remove(2); //        Remove second element from list using index

        list.remove(Integer.valueOf(66));

        int val = list.get(3); //        Add 90 at index 3
        System.out.println(val+90);

        System.out.println(list.size()); //        Get the length of list

        System.out.println("##############***********");

        for (int vit: list) {        //        Print all values from list using any values
            System.out.println(vit);
        }

        Object[] arr = list.toArray();  //        Convert List into array.

        for (Object x : arr) {
            System.out.print(x+" ");
        }
    }
}
