package assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
        //Write a program which will pick the values from Array and Store them List.
        List<Integer> list = new ArrayList<>();
        int arr [] = {2,4,5,7,8,9};
        for (int i = 0; i < arr.length; i++){
            list.add(arr[i]);
        }
        System.out.println(list);
    }
}
