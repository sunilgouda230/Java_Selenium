package assignment3;

import java.util.ArrayList;
import java.util.List;

public class Task6 {
//    Write a program which will display true if list contains Mobile else prints false
//    List  - Web Automation, API Automation, Mobile Automation.
//    Output – True

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Web Automation");
        list.add("API Automation");
        list.add("Mobile Automation");

        boolean ans = getValue(list);
                System.out.println(ans);
        }

        static boolean getValue (List<String> list){
            for (int i = 0; i < list.size(); i++){
                String val = list.get(i);
                if (val.contains("Mobile")){
                        return true;
                }
        }
            return false;
    }
}
