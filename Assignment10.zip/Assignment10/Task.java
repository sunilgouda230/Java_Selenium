package Assignment10;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

public class Task {

    private static final String courseName = "name";
    private static final String description = "//textarea[@id='description']";
    private static final String instructor = "instructorNameId";
    private static final String price = "price";
    private static final String save_btn = "//button[text()='Save']";
    private static final String error_message = "//h2[@class='errorMessage']";
    private static final String cancel_btn = "//button[text()='Cancel']";
    private static final String add_course_title = "//div[text()='Add New Course']";
    private static final String welcome_home_page = "//h4[@class='welcomeMessage']";
    private static final String manage_btn = "//span[text()='Manage']";
    private static final String manage_courses_btn = "//span[text()='Manage Courses']";
    private static final String user_name = "email1";
    private static final String pass_word = "password1";
    private static final String sign_in_btn = "//button[@class='submit-btn']";

    public static void addCourse(String COURSE_NAME, String DESCRIPTION, String INSTRUCTOR, int PRICE, WebDriver driver) throws Exception{
        Actions actions = new Actions(driver);
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement visible_Welcome_msg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(welcome_home_page)));
        if (visible_Welcome_msg.isDisplayed()){
            Thread.sleep(2000);
            actions.moveToElement(driver.findElement(By.xpath(manage_btn))).build().perform();
            driver.findElement(By.xpath(manage_courses_btn)).click();
            driver.findElement(By.xpath("//h1[@class='title']")).click();
            String cururl = driver.getCurrentUrl();
            if (cururl.contains("manage")){
                driver.findElement(By.xpath("//button[normalize-space(text()) = 'Add New Course']")).click();
                fileUpload(driver);
                driver.findElement(By.id(courseName)).sendKeys(COURSE_NAME);
                driver.findElement(By.xpath(description)).sendKeys(DESCRIPTION);
                driver.findElement(By.id(instructor)).sendKeys(INSTRUCTOR);
                driver.findElement(By.id(price)).sendKeys(String.valueOf(PRICE));
                driver.findElement(By.xpath(save_btn)).click();
                String error_msg = driver.findElement(By.xpath(error_message)).getText();
                Assert.assertEquals(error_msg,"All fields are required. Fill all of them");
                selectCategory("Testing",driver);
                selectDateFromToEnd("14","2023","16",driver);
//                JavascriptExecutor js = (JavascriptExecutor)driver;
//                js.executeScript("arguments[0].scrollIntoView(true);", save_btn);
                driver.findElement(By.xpath(save_btn)).click();
                if (driver.findElement(By.xpath("//table[contains(@class,'courses-table')]//following::th[text()='Course Name']//following::td[contains(text(),'"+COURSE_NAME+"')]")).isDisplayed()){
                    driver.findElement(By.xpath("//table[contains(@class,'courses-table')]//following::th[text()='Course Name']//following::td[contains(text(),'"+COURSE_NAME+"')]//..//input")).click();
                    driver.findElement(By.xpath("//table[contains(@class,'courses-table')]//following::th[text()='Course Name']//following::td[contains(text(),'"+COURSE_NAME+"')]//following::button")).click();
                }
            }
            Thread.sleep(3000);
            driver.findElement(By.xpath("//button[text()='Sign out']")).click();
        }
    }

    public static void selectDateFromToEnd(String from, String Year, String to, WebDriver driver){
        LocalDate currentdate = LocalDate.now();
        Month currentMonth = currentdate.getMonth();
        String cur_result = camel_case(currentMonth.toString());
        driver.findElement(By.name("startDate")).click();
        List<WebElement> start_date = driver.findElements(By.xpath("//div[contains(@class,'datepicker__week')]//following-sibling::div[contains(@aria-label,'"+cur_result+"') and @aria-disabled='false']"));
        for (WebElement start: start_date) {
            if (start.getText().equalsIgnoreCase(from)){
                start.click();
                break;
            }
        }
        LocalDate nextMonth = currentdate.plusMonths(1);
        Month nextMonthCalender = nextMonth.getMonth();
        String next_month_camel = camel_case(nextMonthCalender.toString());
        driver.findElement(By.name("endDate")).click();
        List<WebElement> end_date = driver.findElements(By.xpath("//div[contains(@class,'datepicker__week')]//following-sibling::div[contains(@aria-label,'"+next_month_camel+"') and @aria-disabled='false']"));
        for (WebElement end: end_date) {
            if (end.getText().equalsIgnoreCase(to)){
                end.click();
                break;
            }
        }

    }

    public static boolean selectCategory(String category, WebDriver driver){
        driver.findElement(By.xpath("//button[@class='menu-btn']")).click();
        WebElement select_categoty_option = driver.findElement(By.xpath("//div[contains(text(),'Category')]"));
        if (select_categoty_option.isDisplayed()){
            List<WebElement> options = driver.findElements(By.xpath("//div[@class='menu-items']/button"));
            for ( WebElement val: options) {
                if (val.getText().equalsIgnoreCase(category)){
                    val.click();
                    break;
                }
            }
            return true;
        }

        return false;
    }

    public static boolean fileUpload(WebDriver driver){
        try {
            driver.findElement(By.xpath("//input[@type='file']")).sendKeys("/Users/nmsg459/Desktop/dummy.jpeg");
            return true;
        } catch (Exception ex){
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean loginPortal(String username, String Password, WebDriver driver){
        String header = driver.findElement(By.xpath("//h2[@class='header']")).getText();
        if (header.equalsIgnoreCase("Sign In")){
            driver.findElement(By.id(user_name)).sendKeys(username);
            driver.findElement(By.id(pass_word)).sendKeys(Password);
            driver.findElement(By.xpath(sign_in_btn)).click();
            return true;
        }
            return false;
    }

    public static String camel_case(String text) {
        if (!text.equals(" ")) {
//            String result = text.replaceAll("([A-Z])", " $1");
            return text.substring(0, 1).toUpperCase() + text.substring(1).toLowerCase();
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.get("https://ineuron-courses.vercel.app/login");
        driver.manage().window().fullscreen();
        String homePageUrl = driver.getCurrentUrl();
        if (homePageUrl.contains("login")) {
            boolean status = loginPortal("ineuron@ineuron.ai","ineuron",driver);
            if (status) {
                addCourse("JavaWithSelenium","FullStackSDET","Mukesh Sir",5000, driver);
            }
        }

        if (driver.getCurrentUrl().contains("login")){
            System.out.println("Success of the operation");
        }

    }
}
