package Assignment8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.List;

public class Task2 {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        driver.get("https://www.facebook.com/");
        List<WebElement> footerlink = driver.findElements(By.xpath("//div[@id='pageFooter']//following::li/a"));
        for (WebElement val: footerlink
             ) {
            System.out.println(val.getText());
        }
        WebElement createAPageLink = driver.findElement(By.xpath("//div[@id='reg_pages_msg']/a"));

        if (createAPageLink.getText().equalsIgnoreCase("Create a page")){
            createAPageLink.click();
        }
    }
}
