package Assignment8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;


public class Task3 {

    public static final String first_name = "//input[@name='firstname']";
    public static final String sur_name = "//input[@name='lastname']";
    public static final String mob_no = "//input[@name='reg_email__']";
    public static final String password = "//input[@id='password_step_input']";
    public static final String select_day = "day";
    public static final String select_month = "month";
    public static final String select_year = "year";
    public static final String pronoun = "//select[@name='preferred_pronoun']";
    public static String sign_up = "//button[@name='websubmit']";
    public static String create_new_acc = "//a[text()='Create New Account']";

    public static boolean filldetails(WebDriver driver, String fn, String Sn, String mob, String pass,
                                      String day, int month, String year, String gender){


        driver.findElement(By.xpath(first_name)).sendKeys(fn);
        driver.findElement(By.xpath(sur_name)).sendKeys(Sn);
        driver.findElement(By.xpath(password)).sendKeys(pass);
        driver.findElement(By.xpath(mob_no)).sendKeys(mob);

        Select b_day = new Select(driver.findElement(By.xpath("//select[@id='"+select_day+"']")));
        b_day.selectByValue(day);

        Select b_mon = new Select(driver.findElement(By.xpath("//select[@id='"+select_month+"']")));
        b_mon.selectByIndex(month);

        Select b_year = new Select(driver.findElement(By.xpath("//select[@id='"+select_year+"']")));
        b_year.selectByValue(year);

        driver.findElement(By.xpath("//label[text()='"+gender+"']//following-sibling::input[@name='sex']")).click();

        driver.findElement(By.xpath(sign_up)).click();

        return true;

    }

    public static boolean filldetails(WebDriver driver,String fn, String Sn, String mob, String pass,
                                      String day, int month, String year, String custom, int pro_index){

        driver.findElement(By.xpath(first_name)).sendKeys(fn);
        driver.findElement(By.xpath(sur_name)).sendKeys(Sn);
        driver.findElement(By.xpath(password)).sendKeys(pass);
        driver.findElement(By.xpath(mob_no)).sendKeys(mob);

        Select b_day = new Select(driver.findElement(By.xpath("//select[@id='"+select_day+"']")));
        b_day.selectByValue(day);

        Select b_mon = new Select(driver.findElement(By.xpath("//select[@id='"+select_month+"']")));
        b_mon.selectByIndex(month);

        Select b_year = new Select(driver.findElement(By.xpath("//select[@id='"+select_year+"']")));
        b_year.selectByValue(year);

        driver.findElement(By.xpath("//label[text()='"+custom+"']//following-sibling::input[@name='sex']")).click();

        Select optional = new Select(driver.findElement(By.xpath(pronoun)));
        optional.selectByIndex(pro_index);

        driver.findElement(By.xpath(sign_up)).click();

        return true;

    }

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.facebook.com/");
        driver.findElement(By.xpath(create_new_acc)).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        filldetails(driver,"Sunil Kumar","Gouda","8989908536","123kiit","31",6,"1996","Male");
//        filldetails(driver,"Sunil Kumar","Gouda","8989908536","123kiit","31",6,"1996","Custom",2);
    }
}
