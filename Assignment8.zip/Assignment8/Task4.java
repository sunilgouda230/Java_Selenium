package Assignment8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;


public class Task4 {

    public static final String first_name = "input[name='firstname']";
    public static final String sur_name = "input[name='lastname']";
    public static final String mob_no = "input[name*='reg']";
    public static final String password = "input[id='password_step_input']";
    public static final String select_day = "day";
    public static final String select_month = "month";
    public static final String select_year = "year";
    public static final String pronoun = "select[name='preferred_pronoun']";
    public static String sign_up = "button[name='websubmit']";
    public static String create_new_acc = "a[id*='u_0']";

    public static boolean filldetails(WebDriver driver, String fn, String Sn, String mob, String pass,
                                      String day, int month, String year, String gender){


        driver.findElement(By.cssSelector(first_name)).sendKeys(fn);
        driver.findElement(By.cssSelector(sur_name)).sendKeys(Sn);
        driver.findElement(By.cssSelector(password)).sendKeys(pass);
        driver.findElement(By.cssSelector(mob_no)).sendKeys(mob);

        Select b_day = new Select(driver.findElement(By.cssSelector("select[id='"+select_day+"']")));
        b_day.selectByValue(day);

        Select b_mon = new Select(driver.findElement(By.cssSelector("select[id='"+select_month+"']")));
        b_mon.selectByIndex(month);

        Select b_year = new Select(driver.findElement(By.cssSelector("select[id='"+select_year+"']")));
        b_year.selectByValue(year);

        driver.findElement(By.cssSelector("span[data-type='radio'] span:nth-child(2)")).click();

        driver.findElement(By.cssSelector(sign_up)).click();

        return true;

    }


    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.facebook.com/");
        driver.findElement(By.cssSelector(create_new_acc)).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        filldetails(driver,"Sunil Kumar","Gouda","8989908536","123kiit","31",6,"1996","Male");
        System.out.println("Filled all values using CSS Selector!!!");
    }
}
