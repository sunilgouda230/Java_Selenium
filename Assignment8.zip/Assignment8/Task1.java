package Assignment8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Task1 {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        driver.get("https://www.facebook.com/");
        String textfacebook = driver.findElement(By.xpath("//h2[contains(text(),'Facebook helps')]")).getText();
        System.out.println(textfacebook);
    }
}
