package assignment5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Task4 {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        Map<String,String> href = new HashMap<>();
        List<WebElement> hrrefval = driver.findElements(By.xpath("//div[@class='orangehrm-login-footer-sm']/a"));

        for (WebElement val: hrrefval) {
            String curhref = val.getAttribute("href");
            if (curhref.contains("linkedin")) {
                href.put("Linkedin",curhref);
            } if (curhref.contains("facebook")) {
                href.put("Facebook",curhref);
            } if (curhref.contains("twitter")) {
                href.put("twitter",curhref);
            }if (curhref.contains("youtube")) {
                href.put("Youtube",curhref);
            }
        }

        System.out.println(href);
    }
}
