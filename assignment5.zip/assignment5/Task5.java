package assignment5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.List;


public class Task5 {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        List<WebElement> hrrefval = driver.findElements(By.xpath("//div[@class='orangehrm-login-footer-sm']/a"));

        for (WebElement val: hrrefval) {
            String curhref = val.getAttribute("href");
            if (curhref.contains("youtube")){
                System.out.println("Found youtube!!!");
                break;
            }
        }
    }
}
