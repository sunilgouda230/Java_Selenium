package Assignment11;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
    public static boolean takeScreenShot(WebDriver driver){
        try {
            FileHandler.copy(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE),new File("./ScreenShot/screenshot_"+getCurrentTimeDate()+".png"));
        } catch (IOException e) {
            System.out.println("something went wrong"+e.getMessage());
        }
        return false;
    }

    public static String getCurrentTimeDate(){
        String date = new SimpleDateFormat("HH_mm_ss_yyyy_MM_dd").format(new Date());
        return date;
    }
}
