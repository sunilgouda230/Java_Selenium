package Assignment11;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.*;
import java.time.Duration;

public class Assignment11 {

    public static String waitForTheText(WebDriver driver, String text, int timeout, By locator) throws InterruptedException {
        for (int i = 0; i < timeout; i++) {
            try {
                WebElement ele = driver.findElement(locator);
                if (ele.getText().contains(text)) {
                    System.out.println("Text Found "+ text);
                    return ele.getText();
                } else {
                    System.out.println("Current text is "+ele.getText());
                }
            } catch (NoSuchElementException e) {
                System.out.println("Finding the "+text);
            }
            Thread.sleep(2000);
        }
        return null;
    }

    public static String waitUsingWebdriver(int timeout, String text, By locator, WebDriver driver) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        for (int i = 0; i < timeout; i++){
            try {
                WebElement ele  = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                if (ele.getText().contains(text)) {
                    System.out.println("Text Found "+ text);
                    return ele.getText();
                } else {
                    System.out.println("Current text is "+ele.getText());
                }
            } catch (NoSuchElementException ex) {
                System.out.println("No Such Text Is Present");
            }
            Thread.sleep(2000);
        }

        return null;
    }

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("http://seleniumpractise.blogspot.com/2016/08/how-to-use-explicit-wait-in-selenium.html");
        driver.findElement(By.xpath("//button[text()='Click me to start timer']")).click();
        String text = waitUsingWebdriver(20,"WebDriver",By.xpath("//p[@id='demo']"),driver);
        System.out.println("The Text Is Visible----> "+text);
    }
}
