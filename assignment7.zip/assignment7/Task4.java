package assignment7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import java.time.Duration;

public class Task4 {
    public static final String username = "Admin";
    public static final String password = "admin123";
    public static final String login_btn = "//button[normalize-space()='Login']";

    public static final String chrome = "Chrome";

    public static final String firefox = "Firefox";

    public static final String edge = "Edge";

    public static String browsername = chrome;

    public static void main(String[] args) {

        WebDriver driver = null;

        if (browsername.equals(chrome)){
            driver = new ChromeDriver();
        } else if (browsername.equals(edge)){
            driver = new EdgeDriver();
        }else if (browsername.equals(firefox)){
            driver = new FirefoxDriver();
        }

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        String title  = driver.getTitle();
        Assert.assertEquals(title,"OrangeHRM");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        driver.findElement(By.xpath(login_btn)).click();
        String url = driver.getCurrentUrl();
        if (url.contains("dashboard")) {
            driver.findElement(By.xpath("//span[contains(@class,'userdropdown')]/img")).click();
            driver.findElement(By.xpath("//ul[contains(@class,'dropdown')]//a[contains(text(),'Logout')]")).click();
            System.out.println("Logout succesfully");
        }
        boolean home_url = driver.getCurrentUrl().contains("login");
        if (home_url){
            System.out.println("user is in home page now");
        }
    }
}
