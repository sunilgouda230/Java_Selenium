package assignment7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;

public class Task2 {
    public static final String login_btn = "//button[normalize-space()='Login']";

    public static final String chrome = "Chrome";

    public static final String firefox = "Firefox";

    public static final String edge = "Edge";

    public static String browsername = chrome;

    public static void main(String[] args) {
        WebDriver driver = null;

        if (browsername.equals(chrome)){
            driver = new ChromeDriver();
        } else if (browsername.equals(edge)){
            driver = new EdgeDriver();
        }else if (browsername.equals(firefox)){
            driver = new FirefoxDriver();
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        WebElement user_name = driver.findElement(By.name("username"));
        user_name.sendKeys("Admin");
        WebElement password = driver.findElement(By.name("password"));
        driver.findElement(By.xpath(login_btn)).click();
        WebElement aleart = driver.findElement(By.xpath("//input[@name='password']//following::span[1]"));
        //same xpath we can use for username feild by replacing @name = username

        if (aleart.getText().equals("Required")){
            System.out.println("Required Message Displayed");
        }
    }
}
