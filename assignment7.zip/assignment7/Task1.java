package assignment7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import java.time.Duration;

public class Task1 {

    public static final String chrome = "Chrome";

    public static final String firefox = "Firefox";

    public static final String edge = "Edge";

    public static String browsername = chrome;

    public static void main(String[] args) {

        WebDriver driver = null;

        if (browsername.equals(chrome)){
            driver = new ChromeDriver();
        } else if (browsername.equals(edge)){
            driver = new EdgeDriver();
        }else if (browsername.equals(firefox)){
            driver = new FirefoxDriver();
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        WebElement user_name = driver.findElement(By.name("username"));
        WebElement password = driver.findElement(By.name("password"));

       boolean border_user = user_name.getCssValue("border").contains("1px");
        if (border_user){
            System.out.println("border value of username is 1px");
        }

        boolean border_pass = password.getCssValue("border").contains("1px");
        if (border_pass){
            System.out.println("border value of password is 1px");
        }

    }
}
