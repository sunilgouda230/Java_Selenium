import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class RCB {

    @Test
    public void validateTestForeignPlayers(){
        //Parse the json
        JsonPath jsonPath = new JsonPath(Json.TeamRcb);
        //For Storing the Result
        List<String> list = new ArrayList<>();

        // get values from json array
        int sizeOfPlayers = jsonPath.getInt("player.size()");
        for (int i = 0; i < sizeOfPlayers; i++) {
            String country = jsonPath.getString("player["+i+"].country");
            String player = jsonPath.getString("player["+i+"].name");

            if (!country.equalsIgnoreCase("India")) {
                list.add(player);
            }
        }
        Assert.assertEquals(4,list.size());

        System.out.println(list);
    }

    @Test
    public void countOfWicketKeeper(){
        //Parse the json
        JsonPath jsonPath = new JsonPath(Json.TeamRcb);
        //for getting the count of wicket-keepers
        int countWicketKeeper = 0;

        int sizeOfPlayers = jsonPath.getInt("player.size()");

        for (int i = 0; i < sizeOfPlayers; i++){
            String role = jsonPath.getString("player["+i+"].role");
            if (role.equalsIgnoreCase("Wicket-keeper")){
                Assert.assertEquals("Wicket-keeper",role);
                countWicketKeeper++;
            }
        }
        Assert.assertEquals(1,countWicketKeeper);
        System.out.println("No of WicketKeeper "+ countWicketKeeper);
    }
}
