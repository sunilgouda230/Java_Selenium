package assignment4;

import java.util.ArrayList;
import java.util.List;

public class Task5 {

    public static void main(String[] args) {
//        Create a list which can accept another list as an element.
//                List 1- 11,22,33
//        List 2-  9,19,29
//        List 3-  7,17,27

        ArrayList<ArrayList<Integer>> l1=new ArrayList<>();
        ArrayList<Integer> val1 = new ArrayList<>();
        val1.add(11);
        val1.add(22);
        val1.add(33);

        l1.add(val1);

        ArrayList<Integer> val2 = new ArrayList<>();
        val2.add(9);
        val2.add(19);
        val2.add(29);

        l1.add(val2);

        ArrayList<Integer> val3 = new ArrayList<>();
        val3.add(7);
        val3.add(17);
        val3.add(27);

        l1.add(val3);

        System.out.println(l1);

    }

}
