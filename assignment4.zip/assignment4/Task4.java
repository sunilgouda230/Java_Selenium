package assignment4;

import java.util.ArrayList;
import java.util.List;

public class Task4 {

    public static void main(String[] args) {
//        Create a list of values and print the second element, second last element.
//        Input – 10,45, 90,45, 23, 90, 44
//        Output – 45,90

        List<Integer> val = new ArrayList<>();
        val.add(18);
        val.add(45);
        val.add(90);
        val.add(45);
        val.add(23);
        val.add(90);
        val.add(44);

        for (int i = 0; i < val.size(); i++){
            if (i == 1){
                System.out.println(val.get(i));
            }
            if (i == val.size()-2){
                System.out.println(val.get(i));
            }
        }

    }
}
