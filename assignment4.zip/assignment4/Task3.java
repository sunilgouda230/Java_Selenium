package assignment4;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Task3 {
    public static void main(String[] args) {
//        Write a program that will remove duplicate values from List
//        Input – Java, TestNG, Maven, Java,
//                Output – Java, TestNG, Maven

        List<String> list = new ArrayList<>();
        Set<String> res = new HashSet<>();
        list.add("Java");
        list.add("TestNG");
        list.add("Maven");
        list.add("Java");

        for (int i = 0; i < list.size(); i++) {
            res.add(list.get(i));
        }

        System.out.println(res);

    }
}
