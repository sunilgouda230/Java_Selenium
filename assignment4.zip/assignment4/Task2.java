package assignment4;

import java.util.ArrayList;
import java.util.List;

public class Task2 {
    public static void main(String[] args) {
//        Input – Git, Github, GitLab,GitBash, Selenium, Java, Maven
//        Output- Git, Github, Gitlab, GitBash
        List<String> val = new ArrayList<>();
        List<String> res = new ArrayList<>();

        val.add("Git");
        val.add("Github");
        val.add("GitLab");
        val.add("GitBash");
        val.add("Selenium");
        val.add("Java");
        val.add("Maven");

        for (int i = 0; i < val.size(); i++){
            if (val.get(i).startsWith("Git")){
                System.out.println(val.get(i));
            }
        }
    }
}
