package assignment4;

import java.util.ArrayList;
import java.util.List;

public class Task1 {

    public static void main(String[] args) {
//        Input – Java, Selenium, TestNG, Git, Github
//        Output- Github, Git, TestNG, Selenium, Java
        List<String> val = new ArrayList<>();
        val.add("Java");
        val.add("Selenium");
        val.add("TestNG");
        val.add("Git");
        val.add("Github");

        for (int i = val.size()-1; i >= 0; i--){
            String res = val.get(i);
            System.out.print(res+ " ");
        }

    }
}
