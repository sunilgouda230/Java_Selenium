package Assignment6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class Task2 {

    public static final String username = "Admin";
    public static final String password = "admin123";
    public static final String login_btn = "//button[normalize-space()='Login']";

    public static String emp_name = "Odis  Adalwin";

    public static String admin_section = "Admin";
    public static String add_btn = "Add";

    public static String save = "Save";

    public static String save_success = "//p[contains(text(),'Success')]";

    public static String pencil_edit = "pencil";

    public static boolean addUser(WebDriver driver, String username, String password, String emp_name, String user_role,
                                  String status) throws InterruptedException {

        driver.findElement(By.xpath("//ul[contains(@class,'oxd-main')]//span[normalize-space()='"+admin_section+"']")).click();
        driver.findElement(By.xpath("//button[normalize-space()='"+add_btn+"']")).click();

        //1. xpath for user role
        driver.findElement(By.xpath("(//label[normalize-space()='User Role']//following::div[contains(@class,'select-text')]/i)[1]")).click();

        //2. xpath for user role
        //  (//div[text()='-- Select --'])[1]//following::i[1]

        //3. xpath for user role
        //   //label[normalize-space()='User Role']//..//following::i[1]

        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+user_role+"']")).click();

        //1. xpath for Employee name
        driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("A");

        // 2. xpath for Employee name
        // //div[contains(@class,'autocomplete')]//input

        // 3. xpath for Employee name
        // //div[contains(@class,'autocomplete')]/input[contains(@placeholder,'Type')]


        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+emp_name+"']")).click();


        //1. xpath for status
        driver.findElement(By.xpath("(//label[normalize-space()='User Role']//following::div[contains(@class,'select-text')]/i)[2]")).click();

        //2. xpath for status
        // (//div[text()='-- Select --'])[2]//following::i[2]

        //3. xpath for status
        ////label[normalize-space()='User Role']//..//following::i[2]

        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+status+"']")).click();

        // 1. xpath for username
        driver.findElement(By.xpath("//label[text()='Username']//following::input[contains(@class,'oxd-input')][1]")).sendKeys(username);
        // 2. xpath for username
        // //div[contains(@class,'input-group')]//preceding::label[text()='Username']//following::input[1]

        // 3. //label[text()='Username']//following::input[1]

        //1. xpath for password
        driver.findElement(By.xpath("//label[text()='Password']//following::input[@type='password'][1]")).sendKeys(password);
        // 2. xpath for password
        // //div[contains(@class,'input-group')]//preceding::label[text()='Password']//following::input[1]

        // 3. //label[text()='Password']//following::input[1]

        //1. xpath for confirm password
        driver.findElement(By.xpath("//label[text()='Password']//following::input[@type='password'][2]")).sendKeys(password);

        // 2 xpath for confirm password
        // //div[contains(@class,'input-group')]//preceding::label[text()='Confirm Password']//following::input[1]

        // 3. //label[text()='Confirm Password']//following::input[1]

        return true;
    }

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        driver.findElement(By.xpath(login_btn)).click();
        String url = driver.getCurrentUrl();
        if (url.contains("dashboard")) {
            addUser(driver,"sunilgouda305","123@Sunil",emp_name,"Admin","Enabled");
        }

    }
}
