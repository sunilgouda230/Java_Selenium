package Assignment6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Task1 {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        //xpath for username
        driver.findElement(By.xpath("//input[@name='username']"));
        driver.findElement(By.xpath("//input[contains(@name,'user')]"));
        driver.findElement(By.xpath("//*[text()='Username']//following::input[@name='username']"));
        //if we use Password instead Username it will work for Password field as well.

        //css selector for username
        driver.findElement(By.cssSelector("input[name='username']"));
        driver.findElement(By.cssSelector("input[placeholder*='User']"));
        driver.findElement(By.cssSelector("div[class*='oxd-form'] input[placeholder='Username']"));

        //xpath for password
        driver.findElement(By.xpath("//input[@name='password']"));
        driver.findElement(By.xpath("//input[contains(@name,'pass')]"));
        driver.findElement(By.xpath("//*[text()='Password']//following::input[@name='password']"));

        //css selector for password
        driver.findElement(By.cssSelector("input[name='password']"));
        driver.findElement(By.cssSelector("input[placeholder*='Pass']"));
        driver.findElement(By.cssSelector("div[class*='oxd-form'] input[placeholder='Password']"));

        //xpath for login button
        driver.findElement(By.xpath("//button[@type='submit']"));
        driver.findElement(By.xpath("//button[contains(@type,'sub')]"));
        driver.findElement(By.xpath("//button[normalize-space()='Login']"));

        //css selector for login button
        driver.findElement(By.cssSelector("button[type='submit']"));
        driver.findElement(By.cssSelector("button[type*='sub']"));
        driver.findElement(By.cssSelector("div[class*='oxd-form'] button[type='submit']"));




    }
}
