package Assignment6;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class Task3 {

    public static final String username = "Admin";
    public static final String password = "admin123";
    public static final String login_btn = "//button[normalize-space()='Login']";

    public static String emp_name = "Odis  Adalwin";

    public static String admin_section = "Admin";
    public static String add_btn = "Add";

    public static String save = "Save";

    public static String save_success = "//p[contains(text(),'Success')]";

    public static String delete_edit = "trash";

    public static String next_btn = "//span[contains(text(),'Records')]//following::button//i[contains(@class,'chevron')]";

    public static String delete_btn = "//button[normalize-space()='Yes, Delete']";

    public static String profile_btn = "//span[contains(@class,'userdropdown')]/img";

    public static boolean addUser(WebDriver driver, String username, String password, String emp_name, String user_role,
                                  String status) throws InterruptedException {

        driver.findElement(By.xpath("//span[normalize-space()='"+admin_section+"']")).click();
        driver.findElement(By.xpath("//button[normalize-space()='"+add_btn+"']")).click();

        driver.findElement(By.xpath("(//label[normalize-space()='User Role']//following::div[contains(@class,'select-text')]/i)[1]")).click();
        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+user_role+"']")).click();

        driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("o");
        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+emp_name+"']")).click();

        driver.findElement(By.xpath("(//label[normalize-space()='User Role']//following::div[contains(@class,'select-text')]/i)[2]")).click();
        driver.findElement(By.xpath("//div[@role='option']/span[text()='"+status+"']")).click();

        driver.findElement(By.xpath("//label[text()='Username']//following::input[contains(@class,'oxd-input')][1]")).sendKeys(username);

        driver.findElement(By.xpath("//label[text()='Password']//following::input[@type='password'][1]")).sendKeys(password);
        driver.findElement(By.xpath("//label[text()='Password']//following::input[@type='password'][2]")).sendKeys(password);

        Thread.sleep(3000);

        driver.findElement(By.xpath("//button[normalize-space()='"+save+"']")).click();

        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));

//        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(save_success)));
//        String msg =  el.getText();
//        Assert.assertEquals("Successfully Saved",msg);

        if (driver.getCurrentUrl().contains("admin")){
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Employee Name']")));
            boolean isPresentCust = driver.findElements(By.xpath("//div[@class='oxd-table-card']//div[text()='"+username+"']//.//..//..//span/i")).size() > 0;

            while (!isPresentCust){
                driver.findElement(By.xpath(next_btn)).click();
            }
        }


        driver.findElement(By.xpath("//div[@class='oxd-table-card']//div[text()='"+username+"']//.//..//..//span/i")).click();

        driver.findElement(By.xpath("//div[@class='oxd-table-card']//div[text()='"+username+"']//.//..//..//button[@type='button']/i[contains(@class,'"+delete_edit+"')]")).click();

        driver.findElement(By.xpath(delete_btn)).click();

        driver.findElement(By.xpath(profile_btn)).click();

        driver.findElement(By.xpath("//ul[@role='menu']/li/a[text()='Logout']")).click();

        if (driver.getCurrentUrl().contains("login")){
            System.out.println("User Landed to login Page!!!");
        }




        return true;
    }





    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        String title  = driver.getTitle();
        Assert.assertEquals(title,"OrangeHRM");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        driver.findElement(By.name("username")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        driver.findElement(By.xpath(login_btn)).click();
        driver.manage().window().maximize();
        String url = driver.getCurrentUrl();
        if (url.contains("dashboard")) {
            addUser(driver,"sunilgouda011","123@Sunil",emp_name,"Admin","Enabled");
        }

    }
}
